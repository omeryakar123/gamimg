export interface Translation {
  title: string;
  subtitle: string;
  heroHeader: string;
  heroSub: string;
  loginBtn: string;
  registerBtn: string;
  scrollDown: string;
  howItWorks: string;
  howItWorksSub: string;
  howStep1Title: string;
  howStep1Desc: string;
  howStep2Title: string;
  howStep2Desc: string;
  howStep3Title: string;
  howStep3Desc: string;
  aboutTitle: string;
  aboutText: string;
  aboutBlockMarketing: string;
  aboutBlockMarketingSub: string;
  aboutBlockReports: string;
  aboutBlockReportsSub: string;
  aboutBlockPayments: string;
  aboutBlockPaymentsSub: string;
  aboutBlockSupport: string;
  aboutBlockSupportSub: string;
  featuresTitle: string;
  feat1Title: string;
  feat1Desc: string;
  feat2Title: string;
  feat2Desc: string;
  feat3Title: string;
  feat3Desc: string;
  commissionsTitle: string;
  commissionsSub: string;
  commissionsHeadNGR: string;
  commissionsHeadRate: string;
  commissionsNote: string;
  calcHeader: string;
  calcSub: string;
  calcSelectType: string;
  calcMonthlyNGR: string;
  calcActivePlayers: string;
  calcEstimatedEarnings: string;
  contactTitle: string;
  contactFirstName: string;
  contactLastName: string;
  contactEmail: string;
  contactMessage: string;
  contactSend: string;
  contactSuccess: string;
  footerRights: string;
  footerPowered: string;
  sidebarMenu: string;
  bottomHome: string;
  bottomRegister: string;
  bottomSupport: string;
  bottomAccount: string;
  portalHeader: string;
  portalLoggedWelcome: string;
  portalTrackingLinks: string;
  portalGeneratedLink: string;
  portalSubIDPlaceholder: string;
  portalStatsClicks: string;
  portalStatsReg: string;
  portalStatsNDPs: string;
  portalStatsComm: string;
  portalSignOut: string;
  portalTerms: string;
  portalPrivacy: string;
}

export const TRANSLATIONS: Record<"tr" | "en", Translation> = {
  tr: {
    title: "BOVBET",
    subtitle: "AFFİLİATES",
    heroHeader: "BOVBET AFFİLİATES",
    heroSub: "BovBet Affiliate, sektördeki en rekabetçi online affiliate programlarından birini sizlere sunmaktadır. Karşılıklı başarımızı geliştirmek için çalışıyoruz.",
    loginBtn: "Oturum Aç",
    registerBtn: "Kayıt",
    scrollDown: "SCROLL",
    howItWorks: "NASIL ÇALIŞIR?",
    howItWorksSub: "Sadece bir ortaklık hesabı açın, takip bağlantılarınızı ve yaratıcı pazarlama materyallerinizi alın.",
    howStep1Title: "KAYIT",
    howStep1Desc: "Bir ortaklık hesabı açın. Pazarlama araçlarınızı alın ve onları web sitenize yükleyin.",
    howStep2Title: "PROMOSYON",
    howStep2Desc: "Kullanıcılarınızı bize göndermenize yardımcı olmak için elimizden gelen her türlü desteği vereceğiz.",
    howStep3Title: "KAZANÇ",
    howStep3Desc: "Arkanıza yaslanın, rahatlayın ve aylık komisyonlarınızın hesabınızda birikmesini izleyin.",
    aboutTitle: "HAKKIMIZDA",
    aboutText: "Bovbet Affiliate piyasadaki en güvenilir ve seçkin Affiliate programlarından biridir. Her yeni aracı ortaklarımız için rahat ve yönetilebilir hale getirme konusunda çaba sarfetmekteyiz.",
    aboutBlockMarketing: "PAZARLAMA",
    aboutBlockMarketingSub: "CAZİP ARAÇLAR",
    aboutBlockReports: "RAPORLAR",
    aboutBlockReportsSub: "DETAYLI VERİLER",
    aboutBlockPayments: "ÖDEMELER",
    aboutBlockPaymentsSub: "HIZLI TRANSFER",
    aboutBlockSupport: "DESTEK",
    aboutBlockSupportSub: "7/24 YANINIZDA",
    featuresTitle: "ÖZELLİKLERİMİZ",
    feat1Title: "ETKİLİ PAZARLAMA ARAÇLARI",
    feat1Desc: "Etkili pazarlama araçlarımız, bağlı kuruluşların talepleri ve pazarın eğilimleri dikkate alınarak her zaman güncellenmektedir.",
    feat2Title: "GERÇEK ZAMANLI İSTATİSTİKLER",
    feat2Desc: "Tanıtımlarınızın etkisini izleyerek ve doğru verilerin gerçek zamanlı analizini alarak katılımınızı artırın.",
    feat3Title: "A VARAN KAZANÇ",
    feat3Desc: "Trafiğinizi aydan aya arttıracak müthiş Gelir Payı Anlaşmaları, rekabetçi Hybrid ve CPA methodları.",
    commissionsTitle: "KOMİSYONLAR",
    commissionsSub: "Basit, anlaşılır ve modern komisyon planları sunariz. Kazancınızı arttırın.",
    commissionsHeadNGR: "NGR (Net Gelir)",
    commissionsHeadRate: "Komisyon",
    commissionsNote: "Özel bir plan oluşturmak için yöneticimizle iletişime geçin.",
    calcHeader: "KAZANÇ HESAPLAYICI",
    calcSub: "Farklı gelir programları ve trafik boyutları altındaki potansiyel kazancınızı simüle edin.",
    calcSelectType: "Komisyon Planı Seçin",
    calcMonthlyNGR: "Aylık Net Gelir (NGR)",
    calcActivePlayers: "Aktif Yeni Oyuncu Sayısı",
    calcEstimatedEarnings: "Tahmini Aylık Kazancınız",
    contactTitle: "İLETİŞİM",
    contactFirstName: "İsim *",
    contactLastName: "Soyadı *",
    contactEmail: "E-posta *",
    contactMessage: "Mesaj *",
    contactSend: "GÖNDER",
    contactSuccess: "Mesajınız başarıyla gönderildi! Temsilcimiz en kısa sürede sizinle iletişime geçecektir.",
    footerRights: "© 2026 Bovbet Affiliates. Tüm hakları saklıdır.",
    footerPowered: "POWERED BY BETCONSTRUCT",
    sidebarMenu: "MENÜ",
    bottomHome: "Ana Sayfa",
    bottomRegister: "Kayıt",
    bottomSupport: "Destek",
    bottomAccount: "Hesabım",
    portalHeader: "AFFILIATE ORTAKLIK PORTALI",
    portalLoggedWelcome: "Bovbet Affiliates Dünyasına Hoş Geldiniz!",
    portalTrackingLinks: "Referans Linki Oluşturucu",
    portalGeneratedLink: "Sizin Benzersiz Takip Linkiniz:",
    portalSubIDPlaceholder: "İsteğe bağlı Alt-ID (Örn: blog_banner)",
    portalStatsClicks: "Tıklanma Sayısı",
    portalStatsReg: "Kayıtlı Oyuncu",
    portalStatsNDPs: "Aktif Yatırımcı",
    portalStatsComm: "Bu Ayki Hakediş",
    portalSignOut: "Güvenli Çıkış",
    portalTerms: "Şartlar",
    portalPrivacy: "Gizlilik"
  },
  en: {
    title: "BOVBET",
    subtitle: "AFFILIATES",
    heroHeader: "BOVBET AFFILIATES",
    heroSub: "BovBet Affiliate offers you one of the most competitive online affiliate programs in the industry. We work to develop our mutual success.",
    loginBtn: "Oturum Aç", // Or "Login" in our app
    registerBtn: "Kayıt", // Or "Register" in our app
    scrollDown: "SCROLL",
    howItWorks: "HOW IT WORKS?",
    howItWorksSub: "Simply open an affiliate account, pick up your tracking links and creative marketing materials.",
    howStep1Title: "REGISTRATION",
    howStep1Desc: "Open an affiliate account. Grab your marketing tools and upload them to your website.",
    howStep2Title: "PROMOTION",
    howStep2Desc: "We will provide all kinds of support from our end to help you direct your users to us.",
    howStep3Title: "EARNINGS",
    howStep3Desc: "Sit back, relax and watch your monthly commissions accrue in your account.",
    aboutTitle: "ABOUT US",
    aboutText: "Bovbet Affiliate is one of the most reliable and distinguished Affiliate programs in the market. We strive to make transit smooth and manageable for every new partner.",
    aboutBlockMarketing: "MARKETING",
    aboutBlockMarketingSub: "ATTRACTIVE TOOLS",
    aboutBlockReports: "REPORTS",
    aboutBlockReportsSub: "DETAILED DATA",
    aboutBlockPayments: "PAYMENTS",
    aboutBlockPaymentsSub: "FAST TRANSFER",
    aboutBlockSupport: "SUPPORT",
    aboutBlockSupportSub: "BY YOUR SIDE 24/7",
    featuresTitle: "OUR FEATURES",
    feat1Title: "EFFECTIVE MARKETING TOOLS",
    feat1Desc: "Our effective marketing tools are dynamically updated, taking into account the partners' needs and market trends.",
    feat2Title: "REAL-TIME STATS",
    feat2Desc: "Enhance your campaign impact by tracking your views, clicks, and receiving real-time correct data analysis.",
    feat3Title: "EARN UP TO",
    feat3Desc: "Stunning Revenue Share deals, competitive Hybrid and CPA structures that grow your traffic month-over-month.",
    commissionsTitle: "COMMISSIONS",
    commissionsSub: "We offer simple, transparent and modern commission schemes. Maximize your income.",
    commissionsHeadNGR: "NGR (Net Revenue)",
    commissionsHeadRate: "Commission",
    commissionsNote: "Contact our affiliate managers to build a custom customized plan.",
    calcHeader: "EARNINGS CALCULATOR",
    calcSub: "Simulate your prospective income under different commission schemes and traffic sizes.",
    calcSelectType: "Choose Commission Scheme",
    calcMonthlyNGR: "Monthly Net Revenue (NGR)",
    calcActivePlayers: "Number of Active Players",
    calcEstimatedEarnings: "Estimated Monthly Earning",
    contactTitle: "CONTACT",
    contactFirstName: "First Name *",
    contactLastName: "Last Name *",
    contactEmail: "Email *",
    contactMessage: "Message *",
    contactSend: "SEND MESSAGE",
    contactSuccess: "Your message has been successfully sent! Our team will get in touch with you shortly.",
    footerRights: "© 2026 Bovbet Affiliates. All rights reserved.",
    footerPowered: "POWERED BY EVERYMATRIX",
    sidebarMenu: "MENU",
    bottomHome: "Home",
    bottomRegister: "Register",
    bottomSupport: "Support",
    bottomAccount: "Account",
    portalHeader: "AFFILIATE MANAGEMENT CONSOLE",
    portalLoggedWelcome: "Welcome to the world of Bovbet Affiliates!",
    portalTrackingLinks: "Referral Tracking Link Builder",
    portalGeneratedLink: "Your Unique Referral Track Link:",
    portalSubIDPlaceholder: "Optional Sub-ID (e.g. blog_banner)",
    portalStatsClicks: "Accumulated Clicks",
    portalStatsReg: "Registered Players",
    portalStatsNDPs: "Active Depositors",
    portalStatsComm: "Unpaid Commission",
    portalSignOut: "Secure Sign Out",
    portalTerms: "Terms",
    portalPrivacy: "Privacy"
  }
};

export interface SubmittedForm {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  message: string;
  submittedAt: string;
  status: "New" | "Reviewed" | "Contacted" | "Closed";
  adminNotes?: string;
}
