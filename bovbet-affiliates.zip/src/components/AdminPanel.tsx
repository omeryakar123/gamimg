import React, { useState } from "react";
import { Translation, SubmittedForm } from "../types";
import {
  Shield,
  Search,
  CheckCircle,
  HelpCircle,
  Trash2,
  Mail,
  User,
  Clock,
  Inbox,
  Filter,
  CheckSquare,
  FileSpreadsheet,
  RefreshCw,
  Edit2,
  Info,
  ChevronRight,
  ArrowRight,
  Send,
  Lock,
  Unlock,
  CornerDownRight,
  Check
} from "lucide-react";

interface AdminPanelProps {
  t: Translation;
  lang: "tr" | "en";
  forms: SubmittedForm[];
  onUpdateFormStatus: (id: string, status: SubmittedForm["status"]) => void;
  onUpdateFormNotes: (id: string, notes: string) => void;
  onDeleteForm: (id: string) => void;
  onResetSeedData: () => void;
}

export default function AdminPanel({
  t,
  lang,
  forms,
  onUpdateFormStatus,
  onUpdateFormNotes,
  onDeleteForm,
  onResetSeedData
}: AdminPanelProps) {
  // Navigation & Search State
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | SubmittedForm["status"]>("All");
  const [selectedFormId, setSelectedFormId] = useState<string | null>(null);

  // Authentication Lock State (To make/simulate secure admin entries)
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [accessCode, setAccessCode] = useState("");
  const [authError, setAuthError] = useState("");

  // Email reply simulation state
  const [replyMessage, setReplyMessage] = useState("");
  const [sentReplies, setSentReplies] = useState<Record<string, string[]>>({});
  const [localNotes, setLocalNotes] = useState<string>("");

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    // Enforce the required administrator password: admin4441!
    if (accessCode.trim() === "admin4441!") {
      setIsAdminUnlocked(true);
      setAuthError("");
    } else {
      setAuthError(
        lang === "tr"
          ? "Hatalı şifre! Lütfen doğru yönetici şifre kodunu giriniz."
          : "Invalid password! Please type the correct admin password."
      );
    }
  };

  const activeForm = forms.find((f) => f.id === selectedFormId);

  // Filter forms according to search term and selected tab filter
  const filteredForms = forms.filter((f) => {
    const fullName = `${f.firstName} ${f.lastName}`.toLowerCase();
    const email = f.email.toLowerCase();
    const msg = f.message.toLowerCase();
    const search = searchTerm.toLowerCase();

    const matchesSearch =
      fullName.includes(search) || email.includes(search) || msg.includes(search);

    const matchesStatus = statusFilter === "All" || f.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Calculate statistics
  const totalCount = forms.length;
  const newCount = forms.filter((f) => f.status === "New").length;
  const reviewedCount = forms.filter((f) => f.status === "Reviewed").length;
  const contactedCount = forms.filter((f) => f.status === "Contacted").length;
  const closedCount = forms.filter((f) => f.status === "Closed").length;

  const handleSelectForm = (form: SubmittedForm) => {
    setSelectedFormId(form.id);
    setLocalNotes(form.adminNotes || "");
    setReplyMessage("");
  };

  const handleSaveNotes = (id: string) => {
    onUpdateFormNotes(id, localNotes);
  };

  const handleSendSimulatedReply = (id: string) => {
    if (!replyMessage.trim()) return;

    const currentReplies = sentReplies[id] || [];
    setSentReplies({
      ...sentReplies,
      [id]: [...currentReplies, replyMessage]
    });
    setReplyMessage("");

    // Automatically transition ticket state to "Contacted"
    onUpdateFormStatus(id, "Contacted");
  };

  const applyPresetReply = (text: string) => {
    setReplyMessage(text);
  };

  // Export forms as CSV
  const handleExportCSV = () => {
    const headers = "ID,FirstName,LastName,Email,Message,SubmittedAt,Status,AdminNotes\n";
    const rows = forms
      .map(
        (f) =>
          `"${f.id}","${f.firstName.replace(/"/g, '""')}","${f.lastName.replace(
            /"/g,
            '""'
          )}","${f.email}","${f.message.replace(/"/g, '""').replace(/\n/g, " ")}","${
            f.submittedAt
          }","${f.status}","${(f.adminNotes || "").replace(/"/g, '""')}"`
      )
      .join("\n");

    const blob = new Blob([headers + rows], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `bovbet_affiliates_submissions_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="glass-card rounded-2xl p-6 md:p-8 border border-accent-purple/35 relative overflow-hidden" id="admin-panel-console">
      {/* Visual neon atmospheric touches */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-accent-purple/10 rounded-full blur-3xl -z-10 animate-pulse" />
      <div className="absolute bottom-[-100px] left-[-100px] w-80 h-80 bg-accent-purple/5 rounded-full blur-3xl -z-10" />

      {/* ADMIN CONSOLE SECURITY GATE (IF LOCKED) */}
      {!isAdminUnlocked ? (
        <div className="max-w-md mx-auto py-12 text-center space-y-6">
          <div className="inline-flex p-4 bg-accent-purple/10 rounded-full border border-accent-purple/30 text-accent-purple-light shadow shadow-accent-purple/25">
            <Lock className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h3 className="font-display font-bold text-2xl text-white tracking-tight uppercase">
              {lang === "tr" ? "YÖNETİCİ PANELİ" : "SECURE ADMIN AREA"}
            </h3>
            <p className="text-sm text-on-variant px-4">
              {lang === "tr"
                ? "İletişime geçen tüm ortakların mail adreslerini ve detaylı tüm bilgilerini görmek için lütfen doğru şifreyi giriniz."
                : "Please enter the administrative password to gain full access to the affiliate details and contact emails."}
            </p>
          </div>

          <form onSubmit={handleUnlock} className="space-y-4 max-w-sm mx-auto">
            <div className="space-y-1 text-left">
              <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
                {lang === "tr" ? "YÖNETİCİ ŞİFRESİ" : "ADMIN PASSWORD"}
              </label>
              <input
                type="password"
                placeholder={lang === "tr" ? "Yönetici şifresini girin" : "Enter password"}
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-on-surface text-center font-bold text-sm rounded-xl px-4 py-3 outline-none transition-all placeholder:font-normal placeholder:text-on-variant/40"
              />
              {authError && <p className="text-[11px] text-error-base font-semibold mt-1">{authError}</p>}
            </div>

            <button
              type="submit"
              className="w-full bg-accent-purple hover:bg-accent-purple/90 text-white font-bold text-sm py-3.5 rounded-xl transition-all shadow-lg shadow-accent-purple/20 flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              <span>{lang === "tr" ? "Yönetici Panelini Aç" : "Unlock Admin Dashboard"}</span>
            </button>
          </form>

          <p className="text-[10px] text-on-variant/50">
            {lang === "tr" ? "* Gelen başvuru ve üyelik formları tamamen yerel hafızada persisted konumdadır." : "* Lead admissions are stored and persisted securely in offline localStorage."}
          </p>
        </div>
      ) : (
        /* MAIN UNLOCKED WORKSPACE COCKPIT */
        <div className="space-y-6">
          
          {/* Header Actions row */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/5">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-accent-purple/20 border border-accent-purple/35 rounded-full text-accent-purple-light font-display text-[10px] font-black uppercase tracking-widest">
                  {lang === "tr" ? "CANLI MONITOR" : "LIVE CONSOLE MONITOR"}
                </span>
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
              </div>
              <h3 className="font-display font-extrabold text-2xl text-white tracking-tight mt-1 flex items-center gap-2">
                <Shield className="w-6 h-6 text-accent-purple-light" />
                <span>{lang === "tr" ? "Bovbet Form Yönetici Paneli" : "Bovbet Form Admin Cockpit"}</span>
              </h3>
              <p className="text-xs text-on-variant">
                {lang === "tr" 
                  ? "Sisteme düşen tüm kullanıcı başvurularını, isteklerini ve partner tekliflerini anlık kontrol edin." 
                  : "Monitor and manage user ticket logs, feedback, and special proposals submitted by clients."}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleExportCSV}
                className="flex items-center gap-1.5 bg-bg-darkest hover:bg-bg-low border border-white/10 hover:border-emerald-500/40 text-on-variant hover:text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all"
                title={lang === "tr" ? "CSV olarak dışa aktar" : "Export as CSV file"}
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>{lang === "tr" ? "Dışa Aktar (CSV)" : "Export CSV"}</span>
              </button>

              <button
                onClick={onResetSeedData}
                className="flex items-center gap-1.5 bg-bg-darkest hover:bg-bg-low border border-white/10 hover:border-accent-purple-light/40 text-on-variant hover:text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all"
                title="Reset simulation database to initial clean mock state"
              >
                <RefreshCw className="w-4 h-4 text-accent-purple-light" />
                <span>{lang === "tr" ? "Verileri Sıfırla" : "Reset Seeds"}</span>
              </button>

              <button
                onClick={() => setIsAdminUnlocked(false)}
                className="flex items-center gap-1.5 bg-red-950/25 hover:bg-red-950/55 border border-red-900/30 text-red-300 px-4 py-2.5 rounded-xl text-xs font-bold transition-all"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{lang === "tr" ? "Kapat" : "Lock"}</span>
              </button>
            </div>
          </div>

          {/* Quick Stats overview cards */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Stat: Total */}
            <div className="bg-bg-darkest/40 border border-white/5 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] text-on-variant font-bold uppercase tracking-wider">
                {lang === "tr" ? "TOPLAM FORM" : "TOTAL FORMS"}
              </span>
              <span className="text-2xl font-display font-extrabold text-white mt-1">
                {totalCount}
              </span>
            </div>

            {/* Stat: New */}
            <div className="bg-blue-950/20 border border-blue-500/20 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] text-blue-300 font-bold uppercase tracking-wider">
                {lang === "tr" ? "YENİ BAŞVURU" : "NEW (PENDING)"}
              </span>
              <span className="text-2xl font-display font-extrabold text-blue-300 mt-1">
                {newCount}
              </span>
            </div>

            {/* Stat: Reviewed */}
            <div className="bg-amber-950/15 border border-amber-500/20 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider">
                {lang === "tr" ? "İNCELENDİ" : "REVIEWED"}
              </span>
              <span className="text-2xl font-display font-extrabold text-amber-300 mt-1">
                {reviewedCount}
              </span>
            </div>

            {/* Stat: Contacted */}
            <div className="bg-purple-950/20 border border-accent-purple/20 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] text-accent-purple-light font-bold uppercase tracking-wider">
                {lang === "tr" ? "CEVAPLANDI" : "CONTACTED"}
              </span>
              <span className="text-2xl font-display font-extrabold text-accent-purple-light mt-1">
                {contactedCount}
              </span>
            </div>

            {/* Stat: Closed */}
            <div className="bg-emerald-950/20 border border-emerald-500/20 col-span-2 lg:col-span-1 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider">
                {lang === "tr" ? "ÇÖZÜLDÜÖ/ARŞİV" : "RESOLVED/CLOSED"}
              </span>
              <span className="text-2xl font-display font-extrabold text-emerald-300 mt-1">
                {closedCount}
              </span>
            </div>
          </div>

          {/* Core visual layout (Form List + Selected Detail pane) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT SECTION (LG: 7-cols) - Live submissions table/feed */}
            <div className="lg:col-span-7 space-y-4">
              
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row gap-3 bg-bg-darkest p-3 rounded-xl border border-white/5">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-2.5 w-4.5 h-4.5 text-on-variant/60" />
                  <input
                    type="text"
                    placeholder={lang === "tr" ? "İsim, E-posta veya mesaj içeriğinde ara..." : "Search name, email, keywords..."}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-bg-low border border-white/5 focus:border-accent-purple text-xs rounded-lg pl-10 pr-4 py-2 outline-none transition-all"
                  />
                </div>

                <div className="flex items-center gap-1 bg-bg-low p-1 rounded-lg border border-white/5 min-w-[140px]">
                  <Filter className="w-3.5 h-3.5 text-on-variant/60 ml-1.5 shrink-0" />
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as any)}
                    className="bg-transparent text-xs text-on-surface font-semibold focus:ring-0 outline-none border-none py-1.5 pl-1 pr-6 cursor-pointer w-full"
                  >
                    <option value="All">{lang === "tr" ? "Tüm Durumlar" : "All Status"}</option>
                    <option value="New">{lang === "tr" ? "Yeni" : "New"}</option>
                    <option value="Reviewed">{lang === "tr" ? "İncelendi" : "Reviewed"}</option>
                    <option value="Contacted">{lang === "tr" ? "Cevaplandı" : "Contacted"}</option>
                    <option value="Closed">{lang === "tr" ? "Kapalı/Arşiv" : "Closed"}</option>
                  </select>
                </div>
              </div>

              {/* Submitted Forms Feed */}
              {filteredForms.length === 0 ? (
                <div className="bg-bg-darkest/40 rounded-xl p-12 border border-dashed border-white/10 text-center space-y-3">
                  <Inbox className="w-12 h-12 text-on-variant/40 mx-auto" />
                  <p className="text-sm font-semibold text-on-variant">
                    {lang === "tr" ? "Arama kriterlerinize uyan başvuru bulunamadı." : "No submitted forms fit your search filter criteria."}
                  </p>
                  <button
                    onClick={() => {
                      setSearchTerm("");
                      setStatusFilter("All");
                    }}
                    className="text-xs text-accent-purple-light hover:underline font-bold"
                  >
                    {lang === "tr" ? "Filtreleri Temizle" : "Clear Active Filters"}
                  </button>
                </div>
              ) : (
                <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
                  {filteredForms.map((form) => {
                    const isSelected = selectedFormId === form.id;
                    return (
                      <div
                        key={form.id}
                        onClick={() => handleSelectForm(form)}
                        className={`text-left p-4 rounded-xl border transition-all duration-150 cursor-pointer flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 relative ${
                          isSelected
                            ? "bg-bg-high border-accent-purple shadow-lg shadow-accent-purple/10"
                            : "bg-bg-darkest/45 border-white/5 hover:bg-bg-low hover:border-white/10"
                        }`}
                      >
                        {/* Status bar marker */}
                        <div
                          className={`absolute left-0 top-0 bottom-0 w-1.5 rounded-l-xl ${
                            form.status === "New"
                              ? "bg-blue-400"
                              : form.status === "Reviewed"
                              ? "bg-amber-400"
                              : form.status === "Contacted"
                              ? "bg-accent-purple"
                              : "bg-emerald-400"
                          }`}
                        />

                        {/* Submitter Credentials */}
                        <div className="space-y-1.5 pl-2.5 max-w-sm">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-display font-extrabold text-sm text-white">
                              {form.firstName} {form.lastName}
                            </span>
                            {/* Short preview label */}
                            <span className="text-[9px] text-on-variant/50 font-mono">
                              #{form.id}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-xs text-on-variant">
                            <Mail className="w-3.5 h-3.5 text-accent-purple-light/75 shrink-0" />
                            <span className="truncate max-w-[220px]">{form.email}</span>
                          </div>

                          <p className="text-[11px] text-on-variant truncate max-w-xs block italic text-on-variant/80">
                            "{form.message}"
                          </p>
                        </div>

                        {/* Status + Metadata controls column */}
                        <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-2 w-full sm:w-auto shrink-0 border-t sm:border-t-0 border-white/5 pt-2 sm:pt-0">
                          {/* Colored status pills */}
                          <span
                            className={`text-[9px] font-bold uppercase tracking-wide px-2 py-1 rounded-full ${
                              form.status === "New"
                                ? "bg-blue-500/10 text-blue-300 border border-blue-500/25"
                                : form.status === "Reviewed"
                                ? "bg-amber-500/10 text-amber-300 border border-amber-500/25"
                                : form.status === "Contacted"
                                ? "bg-accent-purple/10 text-accent-purple-light border border-accent-purple/25"
                                : "bg-emerald-500/10 text-emerald-300 border border-emerald-500/25"
                            }`}
                          >
                            {form.status === "New" && (lang === "tr" ? "Yeni" : "New")}
                            {form.status === "Reviewed" && (lang === "tr" ? "İncelendi" : "Reviewed")}
                            {form.status === "Contacted" && (lang === "tr" ? "Cevaplandı" : "Completed / Contacted")}
                            {form.status === "Closed" && (lang === "tr" ? "Kapalı" : "Closed")}
                          </span>

                          <div className="flex items-center gap-1.5 text-[10px] text-on-variant/60 font-mono">
                            <Clock className="w-3 h-3 text-on-variant/50" />
                            <span>{form.submittedAt}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* RIGHT SECTION (LG: 5-cols) - Quick Details Panel & Note Writer */}
            <div className="lg:col-span-5 bg-bg-low/40 rounded-xl border border-white/5 p-5 min-h-[460px] relative">
              {activeForm ? (
                <div className="space-y-5">
                  
                  {/* Selected Contact Profile */}
                  <div className="border-b border-white/5 pb-4 space-y-3">
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="bg-accent-purple/10 p-2.5 rounded-xl border border-accent-purple/20 text-accent-purple-light">
                          <User className="w-5 h-5 text-accent-purple-light" />
                        </div>
                        <div>
                          <h4 className="font-display font-extrabold text-base text-white">
                            {activeForm.firstName} {activeForm.lastName}
                          </h4>
                          <span className="text-[10px] text-on-variant/60 font-mono block">
                            {activeForm.submittedAt} • Ticket ID: #{activeForm.id}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          if (confirm(lang === "tr" ? "Bu mesajı silmek istiyor musunuz?" : "Are you sure you want to delete this ticket?")) {
                            onDeleteForm(activeForm.id);
                            setSelectedFormId(null);
                          }
                        }}
                        className="p-2 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 hover:border-red-500/50 text-red-400 hover:text-red-300 rounded-lg transition-all"
                        title={lang === "tr" ? "Mesajı sistemden sil" : "Delete submission ticket permanently"}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="text-xs text-on-variant bg-bg-darkest border border-white/5 rounded-lg p-2.5 flex items-center justify-between">
                      <span className="font-mono text-on-variant/80 truncate pr-4">{activeForm.email}</span>
                      <a
                        href={`mailto:${activeForm.email}`}
                        className="text-accent-purple-light font-bold hover:underline py-0.5 px-2 bg-accent-purple/10 rounded flex items-center gap-1 shrink-0"
                      >
                        <Mail className="w-3 h-3" />
                        <span>Mail To</span>
                      </a>
                    </div>
                  </div>

                  {/* Status update controller */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-0.5">
                      {lang === "tr" ? "BİLET DURUMUNU DEĞİŞTİR" : "CHANGE TICKET PROGRESS STATUS"}
                    </label>
                    <div className="grid grid-cols-4 gap-1.5 bg-bg-darkest border border-white/5 p-1 rounded-xl">
                      {(["New", "Reviewed", "Contacted", "Closed"] as const).map((st) => (
                        <button
                          key={st}
                          onClick={() => onUpdateFormStatus(activeForm.id, st)}
                          className={`py-1.5 text-[9px] font-bold uppercase rounded-lg transition-all ${
                            activeForm.status === st
                              ? st === "New"
                                ? "bg-blue-500 text-white shadow shadow-blue-500/25"
                                : st === "Reviewed"
                                ? "bg-amber-500 text-white shadow shadow-amber-500/25"
                                : st === "Contacted"
                                ? "bg-accent-purple text-white shadow shadow-accent-purple/25"
                                : "bg-emerald-500 text-white shadow shadow-emerald-500/25"
                              : "text-on-variant hover:text-white hover:bg-white/5"
                          }`}
                        >
                          {st === "New" && (lang === "tr" ? "Yeni" : "New")}
                          {st === "Reviewed" && (lang === "tr" ? "İnce" : "Review")}
                          {st === "Contacted" && (lang === "tr" ? "Yanıt" : "Contact")}
                          {st === "Closed" && (lang === "tr" ? "Kapat" : "Close")}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Complete Message Content display */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-0.5">
                      {lang === "tr" ? "KULLANICI MESAJI" : "CLIENT MESSAGE BODY"}
                    </span>
                    <div className="bg-bg-darkest border border-white/5 rounded-xl p-3.5 text-xs text-on-surface leading-relaxed max-h-[160px] overflow-y-auto font-sans">
                      {activeForm.message}
                    </div>
                  </div>

                  {/* Administrative notes writer */}
                  <div className="space-y-1.5 bg-accent-purple/5 border border-accent-purple/15 rounded-xl p-3.5">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] font-bold text-accent-purple-light uppercase tracking-widest">
                        {lang === "tr" ? "YÖNETİCİ NOTLARI" : "INTERNAL ADMIN NOTES"}
                      </span>
                      <button
                        onClick={() => handleSaveNotes(activeForm.id)}
                        className="text-[10px] font-bold text-white hover:text-accent-purple-light bg-accent-purple/20 hover:bg-accent-purple/35 px-2 py-0.5 rounded transition-all"
                      >
                        {lang === "tr" ? "Kaydet" : "Sync Notes"}
                      </button>
                    </div>
                    <textarea
                      rows={2}
                      placeholder={lang === "tr" ? "Yalnızca adminlerin görebileceği iç notlar..." : "Write private internal reminders about this applicant..."}
                      value={localNotes}
                      onChange={(e) => setLocalNotes(e.target.value)}
                      className="w-full bg-bg-darkest/80 border border-white/5 focus:border-accent-purple text-xs rounded-lg p-2 outline-none transition-all resize-none text-on-surface placeholder:text-on-variant/45"
                    />
                  </div>

                  {/* Interactive simulated outbox reply system */}
                  <div className="space-y-3 pt-2 border-t border-white/5">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-[10px] font-bold text-on-variant uppercase tracking-widest flex items-center gap-1.5">
                        <CornerDownRight className="w-3.5 h-3.5 text-accent-purple-light" />
                        {lang === "tr" ? "SİMÜLE MAİL CEVABI GÖNDER" : "SIMULATED OUTBOX RESPONSE"}
                      </span>
                    </div>

                    {/* Pre-written templates chips */}
                    <div className="flex flex-wrap gap-1">
                      <button
                        onClick={() =>
                          applyPresetReply(
                            lang === "tr"
                              ? `Merhaba ${activeForm.firstName},\n\nBaşvurunuz onaylanmıştır! Ortaklık anlaşmanızı hazırlayabilmemiz için Skype/Telegram detaylarınızı veya web sitenizin trafik analizini bizimle paylaşabilir misiniz?\n\nSaygılarımızla,\nBovbet Affiliate Ekibi`
                              : `Hello ${activeForm.firstName},\n\nYour affiliate application has been accepted! Could you please share your traffic screenshots or Skype/Telegram details with us so we can finalize the deals?\n\nBest regards,\nBovbet Affiliate Manager`
                          )
                        }
                        className="text-[9px] bg-white/5 hover:bg-white/10 text-on-variant hover:text-white px-2 py-1 rounded transition-colors"
                      >
                        {lang === "tr" ? "Onay Taslağı" : "Accept Template"}
                      </button>
                      <button
                        onClick={() =>
                          applyPresetReply(
                            lang === "tr"
                              ? `Değerli ${activeForm.firstName},\n\nAylık ne kadar aktif oyuncu veya NGR getirebileceğinizi özetleyebilir misiniz? Sizlere en uygun özel oranları sunmak isteriz.\n\nTeşekkürler.`
                              : `Hi ${activeForm.firstName},\n\nCould you please estimate your expected monthly unique depositors or traffic volumes? We will tailor custom commission schemes for you.\n\nThanks.`
                          )
                        }
                        className="text-[9px] bg-white/5 hover:bg-white/10 text-on-variant hover:text-white px-2 py-1 rounded transition-colors"
                      >
                        {lang === "tr" ? "Trafik Detayı İste" : "Request Traffic Details"}
                      </button>
                    </div>

                    {/* Outbound chat stream log */}
                    {sentReplies[activeForm.id] && sentReplies[activeForm.id].length > 0 && (
                      <div className="space-y-1.5 max-h-[80px] overflow-y-auto bg-bg-darkest/75 p-2 rounded-lg border border-white/5">
                        <span className="text-[8px] font-extrabold uppercase font-mono text-accent-purple-light">
                          {lang === "tr" ? "YANIT GEÇMİŞİ" : "OUTBOUND COMM HISTORY"}
                        </span>
                        {sentReplies[activeForm.id].map((rep, idx) => (
                          <div key={idx} className="text-[11px] text-emerald-300 leading-normal pl-2 border-l border-emerald-500/40 italic">
                            {rep}
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="relative">
                      <textarea
                        rows={3}
                        placeholder={lang === "tr" ? "Cevabınızı buraya yazın veya yukarıdaki taslaklardan birine tıklayın..." : "Draft response message here..."}
                        value={replyMessage}
                        onChange={(e) => setReplyMessage(e.target.value)}
                        className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple text-xs rounded-xl pl-3 pr-10 py-2.5 outline-none transition-all resize-none text-on-surface"
                      />
                      <button
                        onClick={() => handleSendSimulatedReply(activeForm.id)}
                        disabled={!replyMessage.trim()}
                        className="absolute right-2 bottom-3 p-2 bg-accent-purple hover:bg-accent-purple/95 disabled:opacity-30 text-white rounded-lg transition-all cursor-pointer shadow"
                        title={lang === "tr" ? "Gönder ve durumunu 'Cevaplandı' yap" : "Send simulated reply and set status to Contacted"}
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                </div>
              ) : (
                /* No selected form fallback card */
                <div className="absolute inset-x-4 top-1/2 -translate-y-1/2 text-center space-y-3.5 pointer-events-none">
                  <Inbox className="w-10 h-10 text-on-variant/30 mx-auto" />
                  <div>
                    <h5 className="text-xs font-bold text-white uppercase tracking-wider">
                      {lang === "tr" ? "Detayları İnceleyin" : "Select a Submission Ticket"}
                    </h5>
                    <p className="text-[11px] text-on-variant/60 max-w-[220px] mx-auto mt-1 leading-relaxed">
                      {lang === "tr"
                        ? "Sol taraftan herhangi bir kullanıcının başvuru kartına tıklayarak bilet yönetim seçeneklerini, simulated e-posta sistemini ve admin notlarını etkinleştirin."
                        : "Click on any submission ticket on the left pane to view descriptive details, write admin logs, or draft simulated response mailers."}
                    </p>
                  </div>
                </div>
              )}
            </div>

          </div>

          <div className="p-4 rounded-xl border border-white/5 bg-bg-darkest/70 flex items-center gap-3">
            <Info className="w-4 h-4 text-accent-purple-light shrink-0" />
            <p className="text-[10px] text-on-variant/75 leading-relaxed">
              {lang === "tr"
                ? "Sistem demosu: Bu panel gerçek zamanlıdır. Sol alt köşedeki İletişim Formundan yapacağınız her gönderim anında burada canlanır. Başvuru referans numaraları otomatik oluşturulur."
                : "Active simulation context: Form entry records are dynamic. Testing entries submitted through the Contact Form above will immediately append to this table in real-time."}
            </p>
          </div>

        </div>
      )}

    </div>
  );
}
