import React from "react";
import { Translation } from "../types";
import { LayoutDashboard, UserPlus, HelpCircle, UserCheck } from "lucide-react";

interface BottomNavProps {
  t: Translation;
  lang: "tr" | "en";
  activeSection: string;
  setActiveSection: (sec: string) => void;
  onAuthAction: (mode: "login" | "register" | "dashboard") => void;
  currentMode: "login" | "register" | "dashboard";
}

export default function BottomNav({ t, lang, activeSection, setActiveSection, onAuthAction, currentMode }: BottomNavProps) {
  const handleScrollToSec = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleAuthTab = (mode: "login" | "register" | "dashboard") => {
    onAuthAction(mode);
    handleScrollToSec("portal-section");
  };

  return (
    <nav className="fixed bottom-0 left-0 w-full flex justify-around items-center px-4 py-2 bg-bg-card border-t border-accent-border z-50 md:hidden">
      {/* Ana Sayfa / Home */}
      <button
        onClick={() => {
          handleScrollToSec("hero");
        }}
        className={`flex flex-col items-center justify-center p-2 rounded-xl transition-transform active:scale-90 ${
          activeSection === "hero"
            ? "text-white bg-accent-purple"
            : "text-on-variant hover:text-accent-purple-light"
        }`}
      >
        <LayoutDashboard className="w-5 h-5 mb-0.5" />
        <span className="font-semibold text-[10px] tracking-tight">{t.bottomHome}</span>
      </button>

      {/* Kayıt / Register */}
      <button
        onClick={() => handleAuthTab("register")}
        className={`flex flex-col items-center justify-center p-2 rounded-xl transition-transform active:scale-90 ${
          activeSection === "portal-section" && currentMode === "register"
            ? "text-white bg-accent-purple-light bg-accent-purple shadow shadow-accent-purple/40"
            : "text-on-variant hover:text-accent-purple-light"
        }`}
      >
        <UserPlus className="w-5 h-5 mb-0.5" />
        <span className="font-semibold text-[10px] tracking-tight">{t.bottomRegister}</span>
      </button>

      {/* Destek / Support */}
      <button
        onClick={() => handleScrollToSec("contact-section")}
        className={`flex flex-col items-center justify-center p-2 rounded-xl transition-transform active:scale-90 ${
          activeSection === "contact-section"
            ? "text-white bg-accent-purple shadow shadow-accent-purple/40"
            : "text-on-variant hover:text-accent-purple-light"
        }`}
      >
        <HelpCircle className="w-5 h-5 mb-0.5" />
        <span className="font-semibold text-[10px] tracking-tight">{t.bottomSupport}</span>
      </button>

      {/* Hesabım / My Account */}
      <button
        onClick={() => handleAuthTab("login")}
        className={`flex flex-col items-center justify-center p-2 rounded-xl transition-transform active:scale-90 ${
          activeSection === "portal-section" && (currentMode === "login" || currentMode === "dashboard")
            ? "text-white bg-accent-purple-light bg-accent-purple shadow shadow-accent-purple/40"
            : "text-on-variant hover:text-accent-purple-light"
        }`}
      >
        <UserCheck className="w-5 h-5 mb-0.5" />
        <span className="font-semibold text-[10px] tracking-tight">{t.bottomAccount}</span>
      </button>
    </nav>
  );
}
