import React, { useState } from "react";
import { Translation, SubmittedForm } from "../types";
import { Send, CheckCircle2, Loader2, Sparkles } from "lucide-react";

interface ContactFormProps {
  t: Translation;
  lang: "tr" | "en";
  onSubmitForm: (firstName: string, lastName: string, email: string, message: string) => void;
}

export default function ContactForm({ t, lang, onSubmitForm }: ContactFormProps) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simulate database submission network hook
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      
      // Trigger callback to global forms store
      onSubmitForm(firstName, lastName, email, message);
      
      // Reset state
      setFirstName("");
      setLastName("");
      setEmail("");
      setMessage("");

      // Clear success feedback after 8 seconds
      setTimeout(() => {
        setSuccess(false);
      }, 8000);
    }, 1200);
  };

  return (
    <div className="glass-card rounded-2xl p-6 md:p-8 border border-accent-border relative" id="contact-panel">
      {success && (
        <div className="absolute inset-x-4 top-4 bg-accent-purple/95 border border-accent-purple-light/50 p-4 rounded-xl text-white text-xs font-semibold shadow-2xl flex items-start gap-3 z-30 animate-fade-in-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-sm mb-0.5 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-accent-purple-light" />
              {lang === "tr" ? "Mesaj Alındı!" : "Message Received!"}
            </p>
            <p className="text-[11px] leading-relaxed text-on-surface">
              {t.contactSuccess}
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
              {t.contactFirstName}
            </label>
            <input
              type="text"
              required
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-on-surface text-sm rounded-xl px-4 py-3 outline-none transition-all"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
              {t.contactLastName}
            </label>
            <input
              type="text"
              required
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-on-surface text-sm rounded-xl px-4 py-3 outline-none transition-all"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
            {t.contactEmail}
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-on-surface text-sm rounded-xl px-4 py-3 outline-none transition-all"
          />
        </div>

        <div className="space-y-1">
          <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
            {t.contactMessage}
          </label>
          <textarea
            required
            rows={4}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-on-surface text-sm rounded-xl px-4 py-3 outline-none transition-all resize-none"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-accent-purple hover:bg-accent-purple/95 text-white py-3.5 rounded-xl font-bold uppercase tracking-wider text-xs active:scale-98 transition-all flex items-center justify-center gap-2 shadow-lg shadow-accent-purple/20 border border-accent-purple/20 disabled:opacity-50"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{lang === "tr" ? "GÖNDERİLİYOR..." : "SENDING..."}</span>
            </>
          ) : (
            <>
              <Send className="w-3.5 h-3.5" />
              <span>{t.contactSend}</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
