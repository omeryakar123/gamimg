import React, { useState, useRef } from "react";
import { Translation } from "../types";
import {
  User,
  Lock,
  Mail,
  Copy,
  Check,
  Activity,
  ArrowRight,
  Sparkles,
  Link as LinkIcon,
  LogOut,
  UploadCloud,
  FileCheck,
  ShieldCheck,
  ExternalLink
} from "lucide-react";

interface UserPortalProps {
  t: Translation;
  lang: "tr" | "en";
  userEmail: string;
  initialMode?: "login" | "register" | "dashboard";
  onClose?: () => void;
  // State shared with parent so Login/Register buttons trigger it correctly
  currentUser: string | null;
  setCurrentUser: (user: string | null) => void;
  currentMode: "login" | "register" | "dashboard";
  setCurrentMode: (mode: "login" | "register" | "dashboard") => void;
}

export default function UserPortal({
  t,
  lang,
  userEmail,
  onClose,
  currentUser,
  setCurrentUser,
  currentMode,
  setCurrentMode
}: UserPortalProps) {
  // Input fields
  const [emailInput, setEmailInput] = useState(currentUser || userEmail || "omer.yakar333@gmail.com");
  const [passwordInput, setPasswordInput] = useState("••••••••");
  const [firstNameInput, setFirstNameInput] = useState("Omer");
  const [lastNameInput, setLastNameInput] = useState("Yakar");
  const [agreeTerms, setAgreeTerms] = useState(true);

  // Link Generator
  const [subID, setSubID] = useState("");
  const [copied, setCopied] = useState(false);

  // File Upload State
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; size: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Track state
  const generatedLink = `https://bovbet.track/click?aff=42918${subID ? `&subid=${encodeURIComponent(subID)}` : ""}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(generatedLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Drag and Drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const sizeKB = (file.size / 1024).toFixed(1);
      setUploadedFile({
        name: file.name,
        size: `${sizeKB} KB`
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const sizeKB = (file.size / 1024).toFixed(1);
      setUploadedFile({
        name: file.name,
        size: `${sizeKB} KB`
      });
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  // Auth Operations
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentMode === "login") {
      setCurrentUser(emailInput);
      setCurrentMode("dashboard");
    } else {
      // Register logic
      setCurrentUser(emailInput);
      setCurrentMode("dashboard");
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentMode("login");
  };

  return (
    <div className="glass-card rounded-2xl p-6 md:p-8 border border-accent-border relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-accent-purple/10 rounded-full blur-3xl -z-10" />

      {/* MODES: LOGIN OR REGISTER (LOGGED OUT) */}
      {currentUser === null ? (
        <div className="max-w-md mx-auto space-y-6">
          <div className="text-center space-y-1">
            <h3 className="font-display font-bold text-2xl text-white tracking-tight uppercase">
              {currentMode === "login" ? t.loginBtn : t.registerBtn}
            </h3>
            <p className="text-on-variant text-sm">
              {currentMode === "login"
                ? (lang === "tr" ? "Mevcut ortaklık hesabınıza giriş yapın." : "Sign in to your affiliate account.")
                : (lang === "tr" ? "Birkaç adımda Bovbet ortağı olun ve kazanmaya başlayın." : "Become a Bovbet partner and start converting now.")}
            </p>
          </div>

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {currentMode === "register" && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
                    {t.contactFirstName}
                  </label>
                  <input
                    type="text"
                    required
                    value={firstNameInput}
                    onChange={(e) => setFirstNameInput(e.target.value)}
                    className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-white text-sm rounded-xl px-4 py-3 outline-none transition-all"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
                    {t.contactLastName}
                  </label>
                  <input
                    type="text"
                    required
                    value={lastNameInput}
                    onChange={(e) => setLastNameInput(e.target.value)}
                    className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-white text-sm rounded-xl px-4 py-3 outline-none transition-all"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
                {lang === "tr" ? "E-Posta Adresi" : "Email Address"}
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-3.5 w-4.5 h-4.5 text-on-variant/60" />
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-white text-sm rounded-xl pl-12 pr-4 py-3 outline-none transition-all"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-on-variant uppercase tracking-widest pl-1">
                {lang === "tr" ? "Şifre" : "Password"}
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 w-4.5 h-4.5 text-on-variant/60" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-white text-sm rounded-xl pl-12 pr-4 py-3 outline-none transition-all"
                />
              </div>
            </div>

            {currentMode === "register" && (
              <label className="flex items-start gap-2 cursor-pointer select-none py-1 group">
                <input
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-1 rounded border-white/10 text-accent-purple focus:ring-0 focus:ring-offset-0 bg-bg-darkest"
                />
                <span className="text-[11px] text-on-variant/80 leading-normal group-hover:text-on-surface transition-colors">
                  {lang === "tr"
                    ? "Genel Hüküm ve Şartları, Gizlilik Politikası bildirimlerini okudum ve onaylıyorum."
                    : "I have read and agree to the general Terms and Conditions, and Privacy Policy."}
                </span>
              </label>
            )}

            <button
              type="submit"
              disabled={currentMode === "register" && !agreeTerms}
              className="w-full bg-accent-purple hover:bg-accent-purple/95 disabled:opacity-50 text-white font-bold text-sm py-3.5 rounded-xl transition-all shadow-lg hover:shadow-accent-purple/20 flex items-center justify-center gap-1.5 active:scale-98"
            >
              <span>{currentMode === "login" ? t.loginBtn : t.registerBtn}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Toggle link */}
          <div className="text-center text-xs text-on-variant pt-2 border-t border-white/5">
            {currentMode === "login" ? (
              <span>
                {lang === "tr" ? "Hesabınız yok mu? " : "Don't have an account? "}
                <button
                  onClick={() => setCurrentMode("register")}
                  className="text-accent-purple-light font-bold hover:underline"
                >
                  {lang === "tr" ? "Şimdi Kaydolun" : "Register Now"}
                </button>
              </span>
            ) : (
              <span>
                {lang === "tr" ? "Zaten bir hesabınız var mı? " : "Already have an account? "}
                <button
                  onClick={() => setCurrentMode("login")}
                  className="text-accent-purple-light font-bold hover:underline"
                >
                  {lang === "tr" ? "Giriş Yapın" : "Log In"}
                </button>
              </span>
            )}
          </div>
        </div>
      ) : (
        /* MODE: LOGGED IN PORTAL DASHBOARD */
        <div className="space-y-6">
          {/* Dashboard Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-accent-border">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-accent-purple-light uppercase tracking-widest bg-accent-purple/10 border border-accent-purple/20 px-3 py-1 rounded-full">
                {t.portalHeader}
              </span>
              <h3 className="font-display font-extrabold text-2xl text-white tracking-tight mt-1">
                {lang === "tr" ? "Hoş Geldiniz," : "Welcome back,"} <span className="text-accent-purple-light font-bold">{currentUser}</span>!
              </h3>
              <p className="text-sm text-on-variant">
                {t.portalLoggedWelcome}
              </p>
            </div>

            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 border border-accent-purple/20 hover:border-accent-purple/40 bg-bg-darkest hover:bg-bg-card text-on-variant hover:text-white text-xs font-bold rounded-xl transition-all self-start md:self-center"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t.portalSignOut}</span>
            </button>
          </div>

          {/* Stats Bento Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Stat Item 1 */}
            <div className="bg-bg-darkest/50 border border-accent-border/50 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-on-variant/70">
                {t.portalStatsClicks}
              </span>
              <div className="mt-2.5 flex items-baseline justify-between">
                <span className="font-display font-bold text-xl md:text-2xl text-white">
                  14,581
                </span>
                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                  +12.4%
                </span>
              </div>
            </div>

            {/* Stat Item 2 */}
            <div className="bg-bg-darkest/50 border border-accent-border/50 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-on-variant/70">
                {t.portalStatsReg}
              </span>
              <div className="mt-2.5 flex items-baseline justify-between">
                <span className="font-display font-bold text-xl md:text-2xl text-white">
                  343
                </span>
                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                  +8.1%
                </span>
              </div>
            </div>

            {/* Stat Item 3 */}
            <div className="bg-bg-darkest/50 border border-accent-border/50 p-4 rounded-xl flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-on-variant/70">
                {t.portalStatsNDPs}
              </span>
              <div className="mt-2.5 flex items-baseline justify-between">
                <span className="font-display font-bold text-xl md:text-2xl text-white">
                  112
                </span>
                <span className="text-[10px] font-semibold text-accent-purple-light bg-accent-purple/10 px-1.5 py-0.5 rounded">
                  21.2% Conversion
                </span>
              </div>
            </div>

            {/* Stat Item 4 */}
            <div className="bg-bg-low/70 border border-accent-purple/20 p-4 rounded-xl flex flex-col justify-between relative overflow-hidden">
              <div className="absolute -right-2 -bottom-2 w-16 h-16 bg-accent-purple/10 rounded-full blur-xl" />
              <span className="text-[10px] uppercase font-bold tracking-wider text-accent-purple-light">
                {t.portalStatsComm}
              </span>
              <div className="mt-2.5 flex items-baseline justify-between">
                <span className="font-display font-extrabold text-xl md:text-2xl text-accent-purple-light purple-glow-sm">
                  34,750 TL
                </span>
                <span className="text-[10px] font-semibold text-orange-400 bg-orange-500/10 px-1.5 py-0.5 rounded">
                  Pending
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Track Link Builder (Left) */}
            <div className="lg:col-span-7 bg-bg-low/30 border border-white/5 rounded-xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-accent-purple-light" />
                <h4 className="font-semibold text-sm text-white">
                  {t.portalTrackingLinks}
                </h4>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-on-variant/80 uppercase tracking-widest pl-0.5">
                  {t.portalSubIDPlaceholder}
                </label>
                <input
                  type="text"
                  placeholder="e.g. twitter_bio, blog_banner"
                  value={subID}
                  onChange={(e) => setSubID(e.target.value)}
                  className="w-full bg-bg-darkest border border-white/10 focus:border-accent-purple focus:ring-1 focus:ring-accent-purple text-white text-xs rounded-lg px-3.5 py-2.5 outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-on-variant/80 uppercase tracking-widest pl-0.5">
                  {t.portalGeneratedLink}
                </span>
                <div className="flex items-center gap-2 bg-bg-darkest border border-white/10 rounded-xl p-2 relative">
                  <span className="text-xs font-mono text-accent-purple-light/95 overflow-x-auto whitespace-nowrap scrollbar-none pr-12 pl-2 w-full select-all">
                    {generatedLink}
                  </span>
                  <button
                    onClick={handleCopyLink}
                    className="absolute right-2 px-3 py-1.5 bg-accent-purple hover:bg-accent-purple/90 rounded-lg text-white text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Document Verification / Upload Widget (Right) */}
            {/* Satisfying the: "Usability Patterns -> File Upload" guideline. */}
            <div className="lg:col-span-5 bg-bg-low/30 border border-white/5 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-accent-purple-light" />
                  <h4 className="font-semibold text-sm text-white">
                    {lang === "tr" ? "Belge Onay / KYC" : "Document Verification / KYC"}
                  </h4>
                </div>
                {uploadedFile && (
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                    <FileCheck className="w-3 h-3" />
                    <span>Upload Ready</span>
                  </span>
                )}
              </div>

              <p className="text-xs text-on-variant/80">
                {lang === "tr"
                  ? "Komisyon ödemelerini alabilmek için Kimlik ön yüzü veya ikametgah belgesi yükleyin."
                  : "Upload a copy of ID or Address proof to initiate affiliate payout clearance."}
              </p>

              {/* Drag and Drop Zone */}
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={triggerFileSelect}
                className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all duration-200 flex flex-col justify-center items-center gap-1 bg-bg-darkest/30 ${
                  dragActive
                    ? "border-accent-purple bg-accent-purple/10"
                    : "border-white/10 hover:border-accent-purple/50 hover:bg-bg-darkest/60"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFileSelect}
                  accept=".jpg,.jpeg,.png,.pdf"
                  className="hidden"
                />

                {uploadedFile ? (
                  <div className="space-y-1 py-1">
                    <FileCheck className="w-8 h-8 text-accent-purple-light mx-auto" />
                    <p className="text-xs text-white font-bold max-w-[200px] truncate mx-auto">
                      {uploadedFile.name}
                    </p>
                    <p className="text-[10px] text-on-variant/70 font-mono">
                      {uploadedFile.size}
                    </p>
                  </div>
                ) : (
                  <>
                    <UploadCloud className="w-8 h-8 text-on-variant/60 mx-auto" />
                    <p className="text-xs text-white font-bold">
                      {lang === "tr" ? "Yüklemek için sürükle veya tıkla" : "Drag & Drop file or Click to upload"}
                    </p>
                    <p className="text-[9px] text-on-variant/60">
                      PDF, JPG, PNG (Max 5MB)
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
