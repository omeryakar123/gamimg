import React from "react";
import { Globe } from "lucide-react";

interface LanguageSelectorProps {
  lang: "tr" | "en";
  setLang: (lang: "tr" | "en") => void;
}

export default function LanguageSelector({ lang, setLang }: LanguageSelectorProps) {
  return (
    <div className="flex items-center gap-1.5 bg-bg-darkest border border-accent-border p-1 rounded-xl">
      <Globe className="w-3.5 h-3.5 text-accent-purple-light ml-1" />
      <button
        onClick={() => setLang("tr")}
        className={`px-2 py-1 text-xs font-semibold rounded-lg transition-all duration-150 ${
          lang === "tr"
            ? "bg-accent-purple text-white shadow-md shadow-accent-purple/20"
            : "text-on-variant hover:text-on-surface"
        }`}
      >
        TR
      </button>
      <button
        onClick={() => setLang("en")}
        className={`px-2 py-1 text-xs font-semibold rounded-lg transition-all duration-150 ${
          lang === "en"
            ? "bg-accent-purple text-white shadow-md shadow-accent-purple/20"
            : "text-on-variant hover:text-on-surface"
        }`}
      >
        EN
      </button>
    </div>
  );
}
