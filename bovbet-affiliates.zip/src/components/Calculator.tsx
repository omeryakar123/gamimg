import React, { useState, useEffect } from "react";
import { Translation } from "../types";
import { TrendingUp, Coins, Users, Percent, Sparkles } from "lucide-react";

interface CalculatorProps {
  t: Translation;
  lang: "tr" | "en";
}

type CommissionScheme = "revshare" | "cpa" | "hybrid";

export default function Calculator({ t, lang }: CalculatorProps) {
  const [scheme, setScheme] = useState<CommissionScheme>("revshare");
  const [ngr, setNgr] = useState<number>(100000); // Default NGR in TL
  const [activePlayers, setActivePlayers] = useState<number>(25); // Default active depositors

  const [earnings, setEarnings] = useState<number>(0);
  const [currentTierRate, setCurrentTierRate] = useState<number>(17);

  // Helper function to format TL currency beautifully
  const formatTL = (num: number) => {
    return new Intl.NumberFormat(lang === "tr" ? "tr-TR" : "en-US", {
      style: "currency",
      currency: "TRY",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  };

  // Recalculate earnings whenever filters alter
  useEffect(() => {
    let calculated = 0;
    if (scheme === "revshare") {
      let rate = 0.15;
      if (ngr <= 75000) {
        rate = 0.15;
      } else if (ngr <= 150000) {
        rate = 0.17;
      } else if (ngr <= 300000) {
        rate = 0.20;
      } else {
        rate = 0.22;
      }
      setCurrentTierRate(Math.round(rate * 100));
      calculated = ngr * rate;
    } else if (scheme === "cpa") {
      // 500 TL per active depositor
      calculated = activePlayers * 500;
    } else if (scheme === "hybrid") {
      // 10% RevShare + 250 TL CPA per active depositor
      calculated = ngr * 0.10 + activePlayers * 250;
    }
    setEarnings(Math.round(calculated));
  }, [scheme, ngr, activePlayers]);

  return (
    <div className="glass-card rounded-2xl p-6 md:p-8 border border-accent-border relative overflow-hidden" id="income-calculator">
      {/* Decorative ambient background glows */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-accent-purple/10 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent-purple/5 rounded-full blur-3xl -z-10" />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-accent-purple/10 rounded-xl border border-accent-purple/20 text-accent-purple-light">
              <Coins className="w-5 h-5 text-accent-purple-light" />
            </span>
            <h3 className="font-display font-bold text-xl md:text-2xl text-on-surface">
              {t.calcHeader}
            </h3>
          </div>
          <p className="text-on-variant text-sm mt-1 max-w-xl">
            {t.calcSub}
          </p>
        </div>

        {/* Plan selector pills */}
        <div className="flex bg-bg-darkest border border-accent-border p-1 rounded-xl w-fit self-start md:self-center">
          <button
            onClick={() => setScheme("revshare")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 ${
              scheme === "revshare"
                ? "bg-accent-purple text-white shadow shadow-accent-purple/20"
                : "text-on-variant hover:text-on-surface"
            }`}
          >
            RevShare
          </button>
          <button
            onClick={() => setScheme("cpa")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 ${
              scheme === "cpa"
                ? "bg-accent-purple text-white shadow shadow-accent-purple/20"
                : "text-on-variant hover:text-on-surface"
            }`}
          >
            CPA
          </button>
          <button
            onClick={() => setScheme("hybrid")}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 ${
              scheme === "hybrid"
                ? "bg-accent-purple text-white shadow shadow-accent-purple/20"
                : "text-on-variant hover:text-on-surface"
            }`}
          >
            Hybrid
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left column: Controls */}
        <div className="lg:col-span-7 space-y-6">
          {/* NGR Slider - Active when revshare or hybrid chosen */}
          {(scheme === "revshare" || scheme === "hybrid") && (
            <div className="space-y-3 bg-bg-low/40 p-5 rounded-xl border border-white/5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-on-variant uppercase tracking-widest flex items-center gap-2">
                  <TrendingUp className="w-3.5 h-3.5 text-accent-purple-light" />
                  {t.calcMonthlyNGR}
                </label>
                <span className="font-display font-bold text-accent-purple-light text-base md:text-lg">
                  {formatTL(ngr)}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="500000"
                step="5000"
                value={ngr}
                onChange={(e) => setNgr(Number(e.target.value))}
                className="w-full h-1.5 bg-bg-darkest rounded-lg appearance-none cursor-pointer accent-accent-purple"
              />
              <div className="flex justify-between text-[10px] text-on-variant/60 font-semibold font-mono">
                <span>0 TL</span>
                <span>250K TL</span>
                <span>500K+ TL</span>
              </div>
            </div>
          )}

          {/* Active Depositor Slider - Active when CPA or hybrid chosen */}
          {(scheme === "cpa" || scheme === "hybrid") && (
            <div className="space-y-3 bg-bg-low/40 p-5 rounded-xl border border-white/5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-bold text-on-variant uppercase tracking-widest flex items-center gap-2">
                  <Users className="w-3.5 h-3.5 text-accent-purple-light" />
                  {t.calcActivePlayers}
                </label>
                <span className="font-display font-semibold text-accent-purple-light text-base md:text-lg">
                  {activePlayers}
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="150"
                step="1"
                value={activePlayers}
                onChange={(e) => setActivePlayers(Number(e.target.value))}
                className="w-full h-1.5 bg-bg-darkest rounded-lg appearance-none cursor-pointer accent-accent-purple"
              />
              <div className="flex justify-between text-[10px] text-on-variant/60 font-semibold font-mono">
                <span>1 NDP</span>
                <span>75 NDPs</span>
                <span>150+ NDPs</span>
              </div>
            </div>
          )}

          {/* Formula disclosure detail text depending on selection */}
          <div className="text-xs text-on-variant/80 italic leading-relaxed pt-1 bg-accent-purple/5 p-3.5 rounded-xl border border-accent-purple/10 flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-accent-purple-light shrink-0" />
            <span>
              {scheme === "revshare" && (
                lang === "tr"
                  ? `Şu anki tahmini NGR aralığınız için uygulanan komisyon komisyon oranı: %${currentTierRate}`
                  : `Commission rate applied for your estimated NGR band is: ${currentTierRate}%`
              )}
              {scheme === "cpa" && (
                lang === "tr"
                  ? "CPA Modom: Aktif yatırım yapan her oyuncu başına 500 TL sabit kazanç sağlarsınız."
                  : "CPA Plan: You earn a flat 500 TL commission pay for each active depositing player."
              )}
              {scheme === "hybrid" && (
                lang === "tr"
                  ? "Hybrid Model: %10 Gelir Payı ek olarak oyuncu başı 250 TL CPA kazanırsınız. Sınırsız getiri avantajı!"
                  : "Hybrid Model: 10% Revenue Share plus 250 TL CPA per active depositor. Unlimited ceiling advantages!"
              )}
            </span>
          </div>
        </div>

        {/* Right column: Beautiful Neon Gauge Indicator */}
        <div className="lg:col-span-5 bg-bg-darkest/70 border border-accent-border rounded-xl p-6 text-center flex flex-col justify-center items-center h-full min-h-[220px]">
          <span className="text-xs font-bold text-accent-purple-light/80 uppercase tracking-widest mb-1 block">
            {t.calcEstimatedEarnings}
          </span>
          
          <div className="relative flex justify-center items-center my-4">
            {/* Glowing neon ring behind the value */}
            <div className="absolute inset-0 m-auto w-32 h-32 rounded-full bg-accent-purple/20 blur-md glowing-ring animate-pulse" />
            <div className="relative bg-bg-card border border-accent-purple/30 z-10 w-44 h-44 rounded-full flex flex-col justify-center items-center shadow-2xl">
              <Coins className="w-6 h-6 text-accent-purple-light mb-1" />
              <span className="font-display font-extrabold text-3xl text-white tracking-tight purple-glow border-b border-accent-purple/20 pb-1.5 px-3">
                {formatTL(earnings)}
              </span>
              <span className="text-[10px] text-on-variant uppercase tracking-widest font-semibold mt-1 bg-accent-purple/10 px-2 py-0.5 rounded-full">
                {scheme === "revshare" ? `${currentTierRate}% Tier` : scheme.toUpperCase()}
              </span>
            </div>
          </div>

          <p className="text-[10px] text-on-variant/60 font-mono mt-1">
            {lang === "tr"
              ? "* Hesaplamalar simülasyon amaçlıdır. Ay sonu verilerine göre kesinleşir."
              : "* Simulations are for illustrative purposes. Final pay is calculated monthly."}
          </p>
        </div>
      </div>
    </div>
  );
}
