import React from "react";
import { Translation } from "../types";
import { Home, HelpCircle, Info, Star, Percent, MessageCircle, X, ShieldAlert } from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  t: Translation;
  lang: "tr" | "en";
  activeSection: string;
  setActiveSection: (sec: string) => void;
}

export default function Sidebar({ isOpen, setIsOpen, t, lang, activeSection, setActiveSection }: SidebarProps) {
  const menuItems = [
    { id: "hero", label: t.bottomHome, icon: Home },
    { id: "how-it-works", label: t.howItWorks, icon: HelpCircle },
    { id: "about", label: t.aboutTitle, icon: Info },
    { id: "features", label: t.featuresTitle, icon: Star },
    { id: "commissions", label: t.commissionsTitle, icon: Percent },
    { id: "contact-section", label: t.contactTitle, icon: MessageCircle },
  ];

  const handleNav = (id: string) => {
    setActiveSection(id);
    setIsOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <>
      {/* Background Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/70 z-[55] backdrop-blur-md transition-opacity duration-300"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Nav drawer panel */}
      <nav
        className={`fixed top-0 left-0 h-full w-76 z-[60] bg-bg-low border-r border-accent-border shadow-2xl transition-transform duration-300 ease-in-out py-8 flex flex-col justify-between ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="space-y-6">
          <div className="px-6 flex justify-between items-center">
            <span className="font-display font-extrabold text-xs text-accent-purple-light tracking-widest uppercase">
              {t.sidebarMenu}
            </span>
            <button
              className="text-on-variant hover:text-white p-1 rounded-lg hover:bg-white/5 transition-all"
              onClick={() => setIsOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`flex items-center gap-4 px-6 py-4 font-semibold text-sm transition-all duration-200 border-l-4 text-left ${
                    isActive
                      ? "text-accent-purple-light border-accent-purple bg-accent-purple/10"
                      : "text-on-variant border-transparent hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-5 h-5 text-accent-purple-light" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer info in Sidebar */}
        <div className="px-6 space-y-4">
          <div className="flex items-center gap-2 text-error-base text-[10px] font-bold border border-error-base/20 bg-error-bg/15 p-2.5 rounded-lg">
            <span className="w-5 h-5 rounded-full border border-error-base flex items-center justify-center font-bold text-[9px] shrink-0">18+</span>
            <span className="leading-tight uppercase tracking-widest">{lang === 'tr' ? 'AŞIRI BAĞIMLILIK YAPABİLİR' : 'RESPONSIBLE GAMING'}</span>
          </div>
          
          <div className="opacity-30 text-[9px] text-on-variant leading-relaxed">
            <p>Bovbet Affiliates Engine</p>
            <p>Ver. 2026.11.02</p>
          </div>
        </div>
      </nav>
    </>
  );
}
