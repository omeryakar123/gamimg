import React, { useState, useEffect } from "react";
import { TRANSLATIONS, SubmittedForm } from "./types";
import { motion } from "motion/react";
import {
  Menu,
  ChevronDown,
  Compass,
  ArrowDown,
  Info,
  Layers,
  Percent,
  CheckCircle,
  HelpCircle,
  Clock,
  Shield,
  Briefcase,
  TrendingUp,
  Award,
  BookOpen
} from "lucide-react";

// Sub-component imports
import LanguageSelector from "./components/LanguageSelector";
import Calculator from "./components/Calculator";
import UserPortal from "./components/UserPortal";
import ContactForm from "./components/ContactForm";
import AdminPanel from "./components/AdminPanel";
import Sidebar from "./components/Sidebar";
import BottomNav from "./components/BottomNav";

export default function App() {
  const [lang, setLang] = useState<"tr" | "en">("tr");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");

  // Authentication State shared between headers, bottom ribbons, and the main portal
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [currentMode, setCurrentMode] = useState<"login" | "register" | "dashboard">("login");

  const [submittedForms, setSubmittedForms] = useState<SubmittedForm[]>(() => {
    const saved = localStorage.getItem("bovbet_submitted_forms");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: "BOV-9104",
        firstName: "Ahmet",
        lastName: "Yılmaz",
        email: "ahmet.yilmaz@affiliateturkey.com",
        message: "Merhaba Bovbet ekibi, aylık 200,000 TL üzeri NGR üreten aktif bir spor/canlı casino blog ağı sahibiyim. Bu ağ için size özel Hybrid veya yüksek oranlı CPA anlaşması yapabilir miyiz? Gerekirse skype üzerinden görüşebiliriz, iyi çalışmalar.",
        submittedAt: "2026-06-09 14:32",
        status: "New",
        adminNotes: "Yüksek potansiyelli spor blogu sahibi. Skype adresi istenecek."
      },
      {
        id: "BOV-2931",
        firstName: "Sarah",
        lastName: "Jenkins",
        email: "sarah.j@casinoexpert.io",
        message: "Interested in a partnership. We have significant SEO traffic targeting the Turkish and European casino players. Can we connect on Skype or Telegram with the VIP affiliate manager?",
        submittedAt: "2026-06-11 04:12",
        status: "Reviewed",
        adminNotes: "SEO casino uzmanı. Telegram bağlantısı kurulabilir."
      },
      {
        id: "BOV-8402",
        firstName: "Caner",
        lastName: "Polat",
        email: "caner_polat@yandex.ru",
        message: "Ödeme kanallarınız hakkında detaylı bilgi alabilir miyim? Minimum ödeme limiti ne kadar ve Kripto/Tether ile ödeme yapıyor musunuz? Teşekkürler.",
        submittedAt: "2026-06-04 11:15",
        status: "Contacted",
        adminNotes: "Kripto ödeme sordu. Evet yapıyoruz diyerek e-posta gönderildi."
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("bovbet_submitted_forms", JSON.stringify(submittedForms));
  }, [submittedForms]);

  const handleNewSubmission = (firstName: string, lastName: string, email: string, message: string) => {
    const newId = `BOV-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const newRecord: SubmittedForm = {
      id: newId,
      firstName,
      lastName,
      email,
      message,
      submittedAt: formattedDate,
      status: "New",
      adminNotes: ""
    };
    setSubmittedForms(prev => [newRecord, ...prev]);
  };

  const handleUpdateFormStatus = (id: string, status: SubmittedForm["status"]) => {
    setSubmittedForms(prev =>
      prev.map(f => f.id === id ? { ...f, status } : f)
    );
  };

  const handleUpdateFormNotes = (id: string, adminNotes: string) => {
    setSubmittedForms(prev =>
      prev.map(f => f.id === id ? { ...f, adminNotes } : f)
    );
  };

  const handleDeleteForm = (id: string) => {
    setSubmittedForms(prev => prev.filter(f => f.id !== id));
  };

  const handleResetSeedData = () => {
    const defaultSeeds: SubmittedForm[] = [
      {
        id: "BOV-9104",
        firstName: "Ahmet",
        lastName: "Yılmaz",
        email: "ahmet.yilmaz@affiliateturkey.com",
        message: "Merhaba Bovbet ekibi, aylık 200,000 TL üzeri NGR üreten aktif bir spor/canlı casino blog ağı sahibiyim. Bu ağ için size özel Hybrid veya yüksek oranlı CPA anlaşması yapabilir miyiz? Gerekirse skype üzerinden görüşebiliriz, iyi çalışmalar.",
        submittedAt: "2026-06-09 14:32",
        status: "New",
        adminNotes: "Yüksek potansiyelli spor blogu sahibi. Skype adresi istenecek."
      },
      {
        id: "BOV-2931",
        firstName: "Sarah",
        lastName: "Jenkins",
        email: "sarah.j@casinoexpert.io",
        message: "Interested in a partnership. We have significant SEO traffic targeting the Turkish and European casino players. Can we connect on Skype or Telegram with the VIP affiliate manager?",
        submittedAt: "2026-06-11 04:12",
        status: "Reviewed",
        adminNotes: "SEO casino uzmanı. Telegram bağlantısı kurulabilir."
      },
      {
        id: "BOV-8402",
        firstName: "Caner",
        lastName: "Polat",
        email: "caner_polat@yandex.ru",
        message: "Ödeme kanallarınız hakkında detaylı bilgi alabilir miyim? Minimum ödeme limiti ne kadar ve Kripto/Tether ile ödeme yapıyor musunuz? Teşekkürler.",
        submittedAt: "2026-06-04 11:15",
        status: "Contacted",
        adminNotes: "Kripto ödeme sordu. Evet yapıyoruz diyerek e-posta gönderildi."
      }
    ];
    setSubmittedForms(defaultSeeds);
  };

  const [currentRoute, setCurrentRoute] = useState<"home" | "admin" | "portal">(() => {
    const hash = window.location.hash;
    const path = window.location.pathname;
    if (hash === "#/admin" || hash === "#admin" || path.endsWith("/admin") || path.endsWith("/admin/")) {
      return "admin";
    }
    if (hash === "#/portal" || hash === "#portal" || path.endsWith("/portal") || path.endsWith("/portal/")) {
      return "portal";
    }
    return "home";
  });

  const userEmail = "omer.yakar333@gmail.com";
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    const handleLocationChange = () => {
      const hash = window.location.hash;
      const path = window.location.pathname;
      if (hash === "#/admin" || hash === "#admin" || path.endsWith("/admin") || path.endsWith("/admin/")) {
        setCurrentRoute("admin");
      } else if (hash === "#/portal" || hash === "#portal" || path.endsWith("/portal") || path.endsWith("/portal/")) {
        setCurrentRoute("portal");
      } else {
        setCurrentRoute("home");
      }
    };

    window.addEventListener("hashchange", handleLocationChange);
    window.addEventListener("popstate", handleLocationChange);
    const interval = setInterval(handleLocationChange, 600);

    return () => {
      window.removeEventListener("hashchange", handleLocationChange);
      window.removeEventListener("popstate", handleLocationChange);
      clearInterval(interval);
    };
  }, []);

  // Detect which section is currently on screen to update anchors/indicators
  useEffect(() => {
    if (currentRoute !== "home") return;
    const handleScroll = () => {
      const sections = ["hero", "how-it-works", "about", "features", "commissions", "contact-section"];
      const scrollPosition = window.scrollY + 120;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [currentRoute]);

  const handleScrollToSec = (id: string) => {
    if (currentRoute !== "home") {
      setCurrentRoute("home");
      window.location.hash = `#/${id}`;
      setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
          const headerOffset = 70;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
          });
        }
      }, 100);
      return;
    }
    
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleDirectAuth = (mode: "login" | "register" | "dashboard") => {
    setCurrentMode(mode);
    setCurrentRoute("portal");
    window.location.hash = "#/portal";
  };

  return (
    <div className="flex flex-col min-h-screen bg-transparent text-on-surface select-none relative pb-16 md:pb-0">
      
      {/* Top Application Bar */}
      <header className="fixed top-0 w-full z-50 bg-bg-base/90 backdrop-blur-md border-b border-white/5 flex justify-between items-center px-4 md:px-8 h-16 transition-all duration-200">
        <div className="flex items-center gap-3.5">
          <button
            onClick={() => setSidebarOpen(true)}
            className="text-accent-purple-light hover:text-white p-2 hover:bg-white/5 rounded-xl transition-all cursor-pointer"
            aria-label="Open menu drawer"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div 
            onClick={() => handleScrollToSec("hero")}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <img
              src="https://raw.githubusercontent.com/omeryakar123/gamimg/f04dc1be0bd66e15f8d7d6f22ebc8498e3af41ce/bov-logo_300x100__360.png"
              alt="Bovbet Logo"
              className="h-8 md:h-10 w-auto object-contain transition-transform group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Action center header */}
        <div className="flex items-center gap-3">
          <LanguageSelector lang={lang} setLang={setLang} />
          
          {currentUser ? (
            <button
              onClick={() => handleDirectAuth("dashboard")}
              className="text-white bg-accent-purple hover:bg-accent-purple/95 font-sans font-bold text-xs px-4 py-2 rounded-xl transition-all active:scale-95 shadow-lg shadow-accent-purple/20 pr-3 flex items-center gap-1.5"
            >
              <span>{lang === "tr" ? "Hesabım" : "My Console"}</span>
              <BookOpen className="w-3.5 h-3.5" />
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleDirectAuth("login")}
                className="text-on-variant hover:text-white text-xs font-bold px-3 py-2 rounded-xl hover:bg-white/5 transition-all"
              >
                {t.loginBtn}
              </button>
              <button
                onClick={() => handleDirectAuth("register")}
                className="hidden sm:block text-white bg-accent-purple hover:bg-accent-purple/95 font-sans font-bold text-xs px-4 py-2 rounded-xl transition-all active:scale-95 shadow-lg shadow-accent-purple/20"
              >
                {t.registerBtn}
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Embedded Sidebar drawer navigation */}
      <Sidebar
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        t={t}
        lang={lang}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      {/* Main Structural Page Flow */}
      <main className="pt-16 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 space-y-16">
        {currentRoute === "admin" ? (
          <div className="py-8">
            <AdminPanel
              t={t}
              lang={lang}
              forms={submittedForms}
              onUpdateFormStatus={handleUpdateFormStatus}
              onUpdateFormNotes={handleUpdateFormNotes}
              onDeleteForm={handleDeleteForm}
              onResetSeedData={handleResetSeedData}
            />
          </div>
        ) : currentRoute === "portal" ? (
          <div className="py-8">
            <div className="mb-8 text-center space-y-2">
              <h2 className="font-display font-black text-2xl md:text-3xl text-white uppercase tracking-wider">
                {lang === "tr" ? "AFFILIATE GİRİŞ & SİSTEM" : "PARTNER CONSOLE PORTAL"}
              </h2>
              <p className="text-on-variant text-xs max-w-xl mx-auto">
                {lang === "tr"
                  ? "Buradan yeni hesap açabilir, portalı test canlandırmak için mock kayıt yapıp kontrol panelini inceleyebilirsiniz."
                  : "Register a testing account right here to immediately investigate our live tracking, link generators, and KYC integrations."}
              </p>
            </div>

            <UserPortal
              t={t}
              lang={lang}
              userEmail={userEmail}
              currentUser={currentUser}
              setCurrentUser={setCurrentUser}
              currentMode={currentMode}
              setCurrentMode={setCurrentMode}
            />
          </div>
        ) : (
          <>
            {/* HERO BRANDING HERO */}
            <section
              id="hero"
              className="relative min-h-[calc(100vh-160px)] flex flex-col justify-center items-center text-center overflow-hidden py-12 md:py-24"
            >
              {/* Neon atmospheric glow backdrops */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-accent-purple/15 rounded-full blur-3xl -z-10" />
              <div className="absolute top-20 right-10 w-44 h-44 bg-accent-purple/5 rounded-full blur-2xl -z-10" />

              {/* Staggered load transitions */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-2xl space-y-6 flex flex-col items-center"
              >
                <div className="space-y-2">
                  <span className="text-xs md:text-sm font-display font-extrabold text-accent-purple-light tracking-widest uppercase block border-b border-accent-purple/25 pb-2 px-6">
                    {t.title}
                  </span>
                  <h2 className="font-display font-black text-5xl md:text-7xl text-white tracking-widest uppercase mt-4">
                    <span className="purple-glow text-accent-purple-light">{t.subtitle}</span>
                  </h2>
                </div>

                <p className="text-on-variant text-sm md:text-base leading-relaxed max-w-lg">
                  {t.heroSub}
                </p>

                <div className="flex flex-col sm:flex-row gap-4 pt-6 w-full max-w-xs sm:max-w-md justify-center">
                  <button
                    onClick={() => handleDirectAuth("login")}
                    className="bg-accent-purple hover:bg-accent-purple/90 text-white font-bold text-sm py-3.5 px-8 rounded-xl active:scale-95 transition-all shadow-xl shadow-accent-purple/35 text-center flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>{t.loginBtn}</span>
                  </button>
                  <button
                    onClick={() => handleDirectAuth("register")}
                    className="border border-accent-purple/40 hover:border-accent-purple/80 bg-accent-purple/5 text-accent-purple-light font-bold text-sm py-3.5 px-8 rounded-xl active:scale-95 transition-all text-center flex items-center justify-center cursor-pointer"
                  >
                    <span>{t.registerBtn}</span>
                  </button>
                </div>
              </motion.div>

              <div
                onClick={() => handleScrollToSec("how-it-works")}
                className="absolute bottom-6 cursor-pointer text-on-variant hover:text-white flex flex-col items-center gap-1.5 group select-none"
              >
                <span className="font-display font-bold text-[9px] uppercase tracking-[0.25em]">
                  {t.scrollDown}
                </span>
                <ChevronDown className="w-4 h-4 animate-bounce text-accent-purple-light group-hover:scale-125 transition-transform" />
              </div>
            </section>

            {/* SECTION: NASIL ÇALIŞIR? (HOW IT WORKS) */}
            <section id="how-it-works" className="py-8 scroll-mt-20">
              <div className="mb-10 text-left">
                <h2 className="font-display font-extrabold text-2xl md:text-3xl text-white border-l-4 border-accent-purple pl-4 uppercase tracking-wider">
                  {t.howItWorks}
                </h2>
                <p className="mt-2 text-on-variant text-sm italic max-w-2xl pl-1">
                  {t.howItWorksSub}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Step 1 */}
                <div className="glass-card glass-card-hover p-6 rounded-2xl flex flex-col gap-5 items-start">
                  <div className="bg-accent-purple/15 p-3 rounded-xl border border-accent-purple/20 text-accent-purple-light">
                    <Briefcase className="w-7 h-7" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-display font-bold text-lg text-white">
                      {t.howStep1Title}
                    </h3>
                    <p className="text-on-variant text-xs leading-relaxed">
                      {t.howStep1Desc}
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="glass-card glass-card-hover p-6 rounded-2xl flex flex-col gap-5 items-start">
                  <div className="bg-accent-purple/15 p-3 rounded-xl border border-accent-purple/20 text-accent-purple-light">
                    <TrendingUp className="w-7 h-7" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-display font-bold text-lg text-white">
                      {t.howStep2Title}
                    </h3>
                    <p className="text-on-variant text-xs leading-relaxed">
                      {t.howStep2Desc}
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="glass-card glass-card-hover p-6 rounded-2xl flex flex-col gap-5 items-start">
                  <div className="bg-accent-purple/15 p-3 rounded-xl border border-accent-purple/20 text-accent-purple-light">
                    <Award className="w-7 h-7" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-display font-bold text-lg text-white">
                      {t.howStep3Title}
                    </h3>
                    <p className="text-on-variant text-xs leading-relaxed">
                      {t.howStep3Desc}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* SECTION: ABOUT ABOUT (HAKKIMIZDA) */}
            <section id="about" className="py-8 scroll-mt-20">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                {/* Interactive Image Frame */}
                <div className="lg:col-span-6 relative rounded-2xl overflow-hidden aspect-video border border-accent-border shadow-2xl group">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCuz82zDMK28slYloWFnl-gtSnlujLndBLIS1jzlBbCcib6IFHPLJztzuM82STdkCJeAuYEcHPcqlQ6_XHhTerFe-L1sHViR1D84ziVwOUgknBqbM-Kb71PAHDgm8mgws4TT_DCxWAjdD6mtmOsyUHviVJWe_eGGDIyEaHjSRGH1hjUE6BSpRXc5XkpSsq-uk-GtjHuZD3YwdlfFFPvd1BbbTMU4UeIcZygcYHKU3362y3ZAneWlz7zCa85MjfyVGjAhhJd8tfiKks"
                    alt="Bovbet Partners Conference Center"
                    className="object-cover w-full h-full grayscale group-hover:grayscale-0 transition-all duration-700 brightness-85"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-bg-base/95 via-transparent opacity-80" />
                </div>

                {/* Explanatory metadata */}
                <div className="lg:col-span-6 space-y-6">
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-accent-purple-light uppercase tracking-widest">
                      {lang === "tr" ? "BİZ KİMİZ?" : "WHO ARE WE?"}
                    </span>
                    <h2 className="font-display font-extrabold text-2xl md:text-3xl text-white uppercase tracking-wider">
                      {t.aboutTitle}
                    </h2>
                  </div>

                  <p className="text-on-variant text-sm leading-relaxed">
                    {t.aboutText}
                  </p>

                  {/* Bento indicators */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-bg-darkest/60 p-4 border-l-2 border-accent-purple rounded-xl">
                      <span className="font-display font-extrabold text-xs text-white block mb-0.5 tracking-wider">
                        {t.aboutBlockMarketing}
                      </span>
                      <p className="text-[10px] text-accent-purple-light uppercase tracking-widest font-semibold">
                        {t.aboutBlockMarketingSub}
                      </p>
                    </div>
                    <div className="bg-bg-darkest/60 p-4 border-l-2 border-accent-purple rounded-xl">
                      <span className="font-display font-extrabold text-xs text-white block mb-0.5 tracking-wider">
                        {t.aboutBlockReports}
                      </span>
                      <p className="text-[10px] text-accent-purple-light uppercase tracking-widest font-semibold">
                        {t.aboutBlockReportsSub}
                      </p>
                    </div>
                    <div className="bg-bg-darkest/60 p-4 border-l-2 border-accent-purple rounded-xl">
                      <span className="font-display font-extrabold text-xs text-white block mb-0.5 tracking-wider">
                        {t.aboutBlockPayments}
                      </span>
                      <p className="text-[10px] text-accent-purple-light uppercase tracking-widest font-semibold">
                        {t.aboutBlockPaymentsSub}
                      </p>
                    </div>
                    <div className="bg-bg-darkest/60 p-4 border-l-2 border-accent-purple rounded-xl">
                      <span className="font-display font-extrabold text-xs text-white block mb-0.5 tracking-wider">
                        {t.aboutBlockSupport}
                      </span>
                      <p className="text-[10px] text-accent-purple-light uppercase tracking-widest font-semibold">
                        {t.aboutBlockSupportSub}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* SECTION: ÖZELLİKLERİMİZ (OUR FEATURES) */}
            <section id="features" className="py-8 scroll-mt-20">
              <div className="max-w-3xl mx-auto space-y-10">
                <h2 className="font-display font-extrabold text-2xl md:text-3xl text-white text-center uppercase tracking-wider">
                  {t.featuresTitle}
                </h2>

                <div className="space-y-8 pl-4 border-l-2 border-accent-purple/30">
                  {/* Feature 1 */}
                  <div className="space-y-2 relative group">
                    <div className="absolute -left-5 top-0.5 w-1.5 h-1.5 rounded-full bg-accent-purple group-hover:scale-150 transition-all" />
                    <h3 className="font-display font-bold text-sm tracking-widest text-accent-purple-light uppercase flex items-center gap-2">
                      {t.feat1Title}
                    </h3>
                    <p className="text-on-variant text-xs leading-relaxed max-w-2xl">
                      {t.feat1Desc}
                    </p>
                  </div>

                  {/* Feature 2 */}
                  <div className="space-y-2 relative group">
                    <div className="absolute -left-5 top-0.5 w-1.5 h-1.5 rounded-full bg-accent-purple group-hover:scale-150 transition-all" />
                    <h3 className="font-display font-bold text-sm tracking-widest text-accent-purple-light uppercase flex items-center gap-2">
                      {t.feat2Title}
                    </h3>
                    <p className="text-on-variant text-xs leading-relaxed max-w-2xl">
                      {t.feat2Desc}
                    </p>
                  </div>

                  {/* Feature 3 */}
                  <div className="space-y-4 relative group">
                    <div className="absolute -left-5 top-1 w-1.5 h-1.5 rounded-full bg-accent-purple group-hover:scale-150 transition-all" />
                    <div className="flex flex-wrap items-baseline gap-2.5">
                      <span className="text-accent-purple font-display font-black text-3xl md:text-4xl tracking-tight leading-none">
                        22%
                      </span>
                      <h3 className="font-display font-bold text-sm tracking-widest text-accent-purple-light uppercase">
                        {t.feat3Title}
                      </h3>
                    </div>
                    <p className="text-on-variant text-xs leading-relaxed max-w-2xl">
                      {t.feat3Desc}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* SECTION: INTERACTIVE CALCULATOR ENGINE */}
            <section id="commissions" className="py-8 scroll-mt-20 space-y-8">
              <div className="text-left">
                <h2 className="font-display font-extrabold text-2xl md:text-3xl text-white uppercase tracking-wider pl-4 border-l-4 border-accent-purple">
                  {t.commissionsTitle}
                </h2>
                <p className="mt-2 text-on-variant text-sm max-w-2xl pl-1">
                  {t.commissionsSub}
                </p>
              </div>

              <Calculator t={t} lang={lang} />

              {/* Standard grid commission values list */}
              <div className="overflow-hidden rounded-2xl bg-bg-card border border-accent-border/60 shadow-xl">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-bg-darkest/90 border-b border-accent-border">
                    <tr>
                      <th className="px-6 py-4 font-display font-extrabold text-xs text-accent-purple-light uppercase tracking-widest">
                        {t.commissionsHeadNGR}
                      </th>
                      <th className="px-6 py-4 font-display font-extrabold text-xs text-accent-purple-light uppercase tracking-widest text-right">
                        {t.commissionsHeadRate}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-xs">
                    <tr className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4.5 text-on-surface font-semibold">0 - 75,000 TL</td>
                      <td className="px-6 py-4.5 text-accent-purple-light font-extrabold text-right text-sm">15%</td>
                    </tr>
                    <tr className="bg-white/[0.01] hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4.5 text-on-surface font-semibold">75,001 - 150,000 TL</td>
                      <td className="px-6 py-4.5 text-accent-purple-light font-extrabold text-right text-sm">17%</td>
                    </tr>
                    <tr className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4.5 text-on-surface font-semibold">150,001 - 300,000 TL</td>
                      <td className="px-6 py-4.5 text-accent-purple-light font-extrabold text-right text-sm">20%</td>
                    </tr>
                    <tr className="bg-white/[0.01] hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4.5 text-on-surface font-semibold">300,001+ TL</td>
                      <td className="px-6 py-4.5 text-accent-purple-light font-extrabold text-right text-sm">22%</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="p-4 rounded-xl border border-accent-purple/30 bg-accent-purple/5 flex items-center gap-4.5">
                <span className="p-2.5 bg-accent-purple/15 rounded-xl text-accent-purple-light border border-accent-purple/20">
                  <Clock className="w-5 h-5 text-accent-purple-light" />
                </span>
                <p className="text-xs text-on-variant font-medium leading-relaxed">
                  {t.commissionsNote}
                </p>
              </div>
            </section>

            {/* SECTION: İLETİŞİM (CONTACT) */}
            <section id="contact-section" className="py-8 scroll-mt-20">
              <div className="mb-10 text-center">
                <h2 className="font-display font-extrabold text-2xl md:text-3xl text-white uppercase tracking-wider">
                  {t.contactTitle}
                </h2>
                <p className="text-xs text-on-variant max-w-md mx-auto mt-2">
                  {lang === "tr"
                    ? "Affiliate başvuru talepleri veya herhangi bir sorunuz için bize 7/24 ulaşabilirsiniz."
                    : "Submit query tickets or request special commission plans through our secure contact flow."}
                </p>
              </div>

              <div className="max-w-xl mx-auto">
                <ContactForm t={t} lang={lang} onSubmitForm={handleNewSubmission} />
              </div>
            </section>
          </>
        )}
      </main>

      {/* Footer copyright indicators */}
      <footer className="bg-bg-darkest mt-16 pt-12 pb-24 md:pb-12 px-4 text-center border-t border-accent-border relative">
        <div className="max-w-7xl mx-auto space-y-8">
          
          <div className="flex justify-center">
            <div className="w-12 h-12 rounded-full border-2 border-error-base flex items-center justify-center font-bold text-error-base text-sm shadow-lg shadow-error-bg/15 animate-pulse select-none">
              18+
            </div>
          </div>

          {currentRoute === "home" && (
            <nav className="flex flex-wrap justify-center gap-x-6 gap-y-3 text-[10px] uppercase tracking-widest font-bold text-on-variant/80">
              <button onClick={() => handleScrollToSec("about")} className="hover:text-white transition-colors">
                {t.aboutTitle}
              </button>
              <button onClick={() => handleScrollToSec("commissions")} className="hover:text-white transition-colors">
                {t.commissionsTitle}
              </button>
              <button onClick={() => handleScrollToSec("contact-section")} className="hover:text-white transition-colors">
                {t.contactTitle}
              </button>
              <span className="text-on-variant/30 font-light select-none">|</span>
              <button onClick={() => handleDirectAuth("register")} className="hover:text-white transition-colors">
                {t.portalTerms}
              </button>
              <button onClick={() => handleDirectAuth("login")} className="hover:text-white transition-colors">
                {t.portalPrivacy}
              </button>
            </nav>
          )}

          <div className="space-y-1.5 opacity-40 text-on-variant">
            <p className="text-[10px] font-medium">
              {t.footerRights}
            </p>
            <p className="text-[9px] uppercase tracking-wider font-extrabold font-mono">
              {t.footerPowered}
            </p>
          </div>
        </div>
      </footer>

      {/* Viewport footer ribbon wrapper */}
      {currentRoute === "home" && (
        <BottomNav
          t={t}
          lang={lang}
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          onAuthAction={handleDirectAuth}
          currentMode={currentMode}
        />
      )}
    </div>
  );
}
